import { Component, OnInit } from '@angular/core';
import { NavController, NavParams, ToastController, AlertController } from '@ionic/angular';
import Parse from 'parse'
import { Router } from '@angular/router';
import {LoginPage}from '../login/login.page'
@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  name: any;
  email: any;
  username: any;
  password: any;
  isSigningup: boolean;
  constructor(public navCtrl: NavController,private router: Router, public navParams: NavParams,private toastCtrl: ToastController,public alertController: AlertController) { }

  ngOnInit() {
  }
  signUp() {
    this.name
    var reWhiteSpace = /\s/;
    document.getElementById("signUp").innerText="Loading. . .";


    if (reWhiteSpace.test(this.username) || reWhiteSpace.test(this.password)) {
      alert("No empty spaces are allowed");
      // this.navCtrl.push(LoginPage)
      this.router.navigate(['/login'])
      return;
    } else {
      Parse.User.signUp(this.username, this.password, { username: this.username }, this.name).
        then(async (resp) => {
          var UserInfo = Parse.Object.extend("User");
          var userInfo = new UserInfo();
          sessionStorage.setItem('name', this.name)
          console.log('Signed up successfully', resp);

          // Clears up the form
          this.name = '';
          this.password = '';
          this.username = '';

          (await this.toastCtrl.create({
            message: 'Account created successfully',
            duration: 2000
          })).present();

        }, async err => {
          console.log('Error signing in', err);

          (await this.toastCtrl.create({
            message: err.message,
            duration: 2000
          })).present();
          this.router.navigate(['/register'])
        });
    }
    document.getElementById("signUp").innerText="Register";

  }
  cancel(){
    this.router.navigate(['/login'])

  }
  // verifyEmailAlert(){
  //   const alert =  this.alertController.create({
  //     cssClass: 'customAlert',
      
  //     message: 'A message has been sent to your registered email.Please verify to login.',
  //     buttons: ['OK']
  //   });

  //    alert.present();
  //    this.navCtrl.setRoot(LoginPage)
  // }


}
