import { Component } from '@angular/core';
import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
import Parse from 'parse'
import { Router } from '@angular/router';
Parse.serverURL = 'https://parseapi.back4app.com/';
  Parse.initialize("k07pXEDU2NFcuH3FyoqXPqRdgLi3xPr2bGIg9ToI", "omLEEYHImys0VU9T7ZOXhImp8lfI8VZbgxpzoa9L");
  declare var addToDb:any;
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss']
})
export class homePage {

  constructor(private barcodeScanner: BarcodeScanner,private router: Router) { }
  scan() {
    this.barcodeScanner.scan().then(barcodeData => {
      console.log('Barcode data', JSON.stringify(barcodeData));

      addToDb(barcodeData);

    }).catch(err => {
      console.log('Error', err);
    });
  }
  logOut(){
    this.router.navigate(['/login'])

  }
}
