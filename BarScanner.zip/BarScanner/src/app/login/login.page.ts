import { Component, OnInit } from '@angular/core';
import Parse from 'parse'
import { NavController, NavParams, ToastController, AlertController } from '@ionic/angular';

import { homePage } from '../home/home.page';
  import { RegisterPage } from '../register/register.page';
  import { Router } from '@angular/router';
  Parse.serverURL = 'https://parseapi.back4app.com/';
  Parse.initialize("k07pXEDU2NFcuH3FyoqXPqRdgLi3xPr2bGIg9ToI", "omLEEYHImys0VU9T7ZOXhImp8lfI8VZbgxpzoa9L");
  
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  username:any;
  password:any;
  // email:any;
  constructor(public navCtrl: NavController,private router: Router, public navParams: NavParams,private toastCtrl: ToastController,public alertController: AlertController) { 
    
  }

  ngOnInit() {
  }
  signUp(){
    console.log("signUp")
    this.router.navigate(['/register'])
  }
  signIn(){
    console.log(this.password);
    console.log(this.username);
    (<HTMLInputElement>document.getElementById("login")).innerText="Loading. . .";
    //document.getElementById("loginSpin").style.display="block";
      Parse.User.logIn(this.username, this.password)
      .then((user) => {
          console.log('Logged in successfully', user);
          this.startSession()
          //this.navCtrl.push(HomePage)
      }, async err => {
          alert(err);
          // this.navCtrl.setRoot(anOtherPage);
          ;(await this.toastCtrl.create({
          message: err.message,
          duration: 2000
        })).present();
      });
  
    //this.navCtrl.push(LoginPage)

  }
  startSession(){
    var currentUser = Parse.User.current();
    var userId = currentUser.id;
    console.log(userId)
    sessionStorage.setItem('userId',userId)
    localStorage.setItem('userId',userId)
    this.router.navigate(['/tabs'])
    // document.getElementById("appFooter").style.display="block";

  }
}
