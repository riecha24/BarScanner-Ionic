Parse.initialize("k07pXEDU2NFcuH3FyoqXPqRdgLi3xPr2bGIg9ToI", "omLEEYHImys0VU9T7ZOXhImp8lfI8VZbgxpzoa9L");

Parse.serverURL = 'https://parseapi.back4app.com/';
var currUser = localStorage.getItem('userId')

function loadScans() {
    var currUser = localStorage.getItem("userId")
    var barScansQuery = new Parse.Query("BarScans");
    barScansQuery.equalTo("userId", currUser);
    barScansQuery.find({
        success: function (userbarScans) {
            //if barScans is already present assign barScans id for app
            if (userbarScans.length > 0) {
                console.log(userbarScans)
                scans = userbarScans.map(item => {
                    var itemArray = []

                    var text = item.attributes.text;
                    var format = item.attributes.format;
                    var cancelled = item.attributes.cancelled;
                    itemArray = [text, format, cancelled,"Delete"]
                    console.log(itemArray)
                    return itemArray
                })
                displayTable(scans);

            }


        }, error: function (error) {
            alert(error)
        }

    })

}
function addToDb(data) {
    console.log(data.text)
    var currUser = localStorage.getItem("userId")
    var barScansQuery = new Parse.Query("BarScans");
    barScansQuery.equalTo("text", data.text);
    barScansQuery.equalTo("userId", currUser)
    barScansQuery.find({
        success: function (userbarScans) {
            //if barScans is already present assign barScans id for app
            if (userbarScans.length > 0 || data.text == "") {
                console.log("return")
                return;
            } else {
                var barScansObj = Parse.Object.extend("BarScans");
                var barScansInfo = new barScansObj();
                // barScansInfo.set("name", "namebarScans");
                barScansInfo.set("text", data.text)
                barScansInfo.set("format", data.format)
                barScansInfo.set("cancelled", data.cancelled)
                barScansInfo.set("userId", currUser)
                barScansInfo.save(null, {
                    success: function (barScansInfo) {
                        // Execute any logic that should take place after the object is saved.
                        // window.location = "new.html";
                        console.log("saved with barScansInfo" + barScansInfo)


                    },
                    error: function (barScansInfo, error) {

                        console.log('Encountered problem with format of barScans information provided by you. ');
                    }
                });

            }


        }, error: function (error) {
            alert(error)
        }

    })




}
function displayTable(scans) {
    var colData = ["Text", "Format", "Cancelled", "Delete"];
    //for scans with both the scans[0]and scans[1] occupied



    var data = {
        "Cols": colData,

        "Rows": scans
    };
    var table = $('<table/>').attr("id", "userquerytable").addClass("display").attr("cellspacing", "0").attr("width", "100%");
    var tr = $('<tr/>');
    table.append('<thead style="background-color:#0373A2;color:white;font-family: Oswald, sans-serif;">').children('thead').append(tr);

    for (var i = 0; i < data.Cols.length; i++) {
        tr.append('<td style="font-size:18px;padding:2px;text-align:center;">' + data.Cols[i] + '</td>');
    }

    for (var r = 0; r < data.Rows.length; r++) {
        var tr = $('<tr/>');
        table.append(tr);
        for (var c = 0; c < data.Cols.length; c++) {

            //tr.append('<td style="font-size:12px;text-align:center;" onclick="javascript:selectScan(rowD[' + r + '][4],rowD[' //+ r + '][3],rowD[' + r + '][1]);"  >' + data.Rows[r][c] + '</td>');
             //tr.append('<td style="font-size:12px;text-align:center;"   >' + data.Rows[r][c] + '</td>');
             
             //tr.append('<td style="font-size:12px;text-align:center;"   >' + data.Rows[r][c] + '<td> <input type="button" 
             //value="Delete" onclick="callMe()"></td>');
             //tr.append('</td>');
var v = data.Rows[0][0]
console.log(v)

            if (data.Rows[r][c] == "Delete") {
                data.Rows[r][c] = ""
                tr.append('<td> <input type="button" value="Delete" onclick="callMe(scans[' + r + '][0])"></td>');
                console.log('Inside delete')
            }
            tr.append('<td style="font-size:12px;text-align:center;"   >' + data.Rows[r][c] + '');

            tr.append('</td>');


        }



    }

    $('#Table').html("");
    $('#Table').append(table);
    $('#userquerytable').DataTable({
        responsive: true,
        paging: true,


    });



}
function selectScan(activityId, downloadFileUrl, downloadFName) {
    document.getElementById("downloadFile").style.display = "block"
    downloadDetails = downloadFileUrl
    downloadFileName = downloadFName
    sessionStorage.setItem("downloadLink", downloadFileUrl)
   


}


    function callMe(dataa){
        console.log('Inside callMe:  '+dataa)
        var barScansQueryDelete = new Parse.Query("BarScans");
        barScansQueryDelete.equalTo("userId", currUser);
        barScansQueryDelete.equalTo("text", dataa);
        barScansQueryDelete.find({
            success: function (userbarScans) {
                //if barScans is already present assign barScans id for app
                if (userbarScans.length > 0) {
                    userbarScans[0].destroy({});
                    alert("Object Deleted Successfully")
                    loadScans();
                    
    
                }
    
    
            }, error: function (error) {
                alert(error)
            }
    
        })
    
    }
